﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTraining.ViewModel;
using WpfTraining.Constraints;

namespace WpfTraining
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void cboPriceLevel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cboBillTo != null && cboPaymentTerms != null && tboPaymentMethod != null)
            {
                if (cboPriceLevel.SelectedValue.ToString() == PriceLevel.Internal_Price.ToString())
                {
                    cboBillTo.IsEnabled = false;
                    cboPaymentTerms.IsEnabled = false;
                    tboPaymentMethod.IsEnabled = false;
                }
                else
                {
                    cboBillTo.IsEnabled = true;
                    cboPaymentTerms.IsEnabled = true;
                    tboPaymentMethod.IsEnabled = true;
                }
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            ShowAllInfo();
        }

        private void CutContractKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.S && Keyboard.Modifiers == ModifierKeys.Control)
            {
                ShowAllInfo();
            }
        }

        private void ShowAllInfo()
        {
            var vm = (OrderViewModel)this.DataContext;
            MessageBox.Show("Code: " + vm.Order.Code
                               + "\nCurrency Code: " + vm.Order.CurrencyCode
                               + "\nPrice Level: " + vm.Order.PriceLevel);
        }
    }
}
