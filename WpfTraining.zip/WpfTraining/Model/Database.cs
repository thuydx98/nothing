﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Model.Models;

namespace WpfTraining.Model
{
    public class Database
    {
        private static Database _instance;

        public List<Person> employees;
        public List<Person> customers;
        public List<PaymentTerm> paymentTerms;
        public List<Location> locations;

        public Order order;

        public static Database Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new Database();
                return _instance;
            }
            set
            {
                _instance = value;
            }
        }

        private Database()
        {
            employees = new List<Person>() {
                new Employee() { Id = "SALES13020001", Name = "Charles Gordon"},
                new Employee() { Id = "SALES13020002", Name = "Katilat Issue"}
            };

            customers = new List<Person>() {
                new Customer() { Id = "CUS19020001", Name = "Light Packet"},
                new Customer() { Id = "CUS19020002", Name = "Kim See Jong"}
            };

            paymentTerms = new List<PaymentTerm>()
            {
                new PaymentTerm(){ TermName = "0 Days"},
                new PaymentTerm(){ TermName ="7 Days"},
                new PaymentTerm(){ TermName ="30 Days"}
            };

            locations = new List<Location>()
            {
                new Location(){ LocationName = "London"},
                new Location(){ LocationName = "Stanley"}
            };

            order = new Order()
            {
                Code = "INV13030002",
                CurrencyCode = "USA",
                PriceLevel = Constraints.PriceLevel.Regular_Price,
                Date = Convert.ToDateTime("2013/3/20"),
                DueDate = Convert.ToDateTime("2013/4/19"),
                Customer = customers[1] as Customer,
                OrderNo = "122929",
                Sale = employees[0] as Employee,
                PaymentTerm = paymentTerms[2],
                ShippingTo = locations[1],
                BillTo = locations[1],
                ShippingTerm = "",
                ShippingDate = Convert.ToDateTime("2013/4/12"),
                PaymentMethod = "Cheque",
                ListOrderDetail = new ObservableCollection<OrderDetail>()
                {
                    new OrderDetail() { Seq = 1, ItemCode = "STK000001", Description="APPLE IPAD CASING - WHITE", UOM = "PC", UnitPrice = 160, Quantity = 30, Disc = 0, Tax = 1},
                    new OrderDetail() { Seq = 2, ItemCode = "STK000003", Description="SAMSUNG GALAXY TAB 10.1'' CASING - BLACK", UOM = "PC", UnitPrice = 40.00, Quantity = 50, Disc = 0.00, Tax = 1},
                    new OrderDetail() { Seq = 3, ItemCode = "STK000004", Description="SAMSUNG GALAXY TAB 10.1'' CASING - WHITE", UOM = "PC", UnitPrice = 40.00, Quantity = 50, Disc = 0.00, Tax = 1}
                }
            };
        }
    }
}
