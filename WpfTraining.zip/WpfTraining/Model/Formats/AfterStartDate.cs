﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WpfTraining.Model.Formats
{
    public class AfterStartDate : ValidationAttribute
    {
        public string StartDatePropertyName { get; set; }
        public string EndDate { get; set; }


        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            PropertyInfo startDateProperty = validationContext.ObjectType.GetProperty(StartDatePropertyName);

            DateTime startDate = (DateTime)startDateProperty.GetValue(validationContext.ObjectInstance, null);

            DateTime endDate = DateTime.Parse(EndDate);

            DateTime chosenDate = DateTime.Parse(value.ToString());

            if (chosenDate > startDate && chosenDate < endDate)
            {
                return ValidationResult.Success;
            }
            else
            {
                return new ValidationResult("Range of DueDate was wrong", new string[] { validationContext.DisplayName });
            }
        }

    }
}
