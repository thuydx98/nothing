﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTraining.Model.Models
{
    public class Location
    {
        private string _LocationName;

        public string LocationName
        {
            get { return _LocationName; }
            set
            {
                _LocationName = value;
            }
        }
    }
}
