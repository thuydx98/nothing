﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Constraints;
using WpfTraining.Model.Formats;

namespace WpfTraining.Model.Models
{
    public class Order : BaseViewModel
    {
        private string _Code;
        private string _CurrencyCode;
        private PriceLevel _PriceLevel;
        private Customer _Customer;
        private Employee _Sale;
        private string _OrderNo;
        private DateTime _Date;
        private DateTime _DueDate;
        private PaymentTerm _PaymentTerm;
        private Location _ShippingTo;
        private Location _BillTo;
        private string _ShippingTerm;
        private string _PaymentMethod;
        private DateTime _ShippingDate;
        private ObservableCollection<OrderDetail> _ListOrderDetail;

        public DateTime Date
        {
            get { return _Date; }
            set
            {
                _Date = value;
                ValidateProperty(value);
                OnPropertyChanged("Date");
            }
        }

        [AfterStartDate(StartDatePropertyName = "Date", EndDate = "2020/01/01")]
        public DateTime DueDate
        {
            get { return _DueDate; }
            set
            {
                _DueDate = value;
                ValidateProperty(value);
                OnPropertyChanged("DueDate");
            }
        }

        [MinLength(3), MaxLength(3)]
        public string CurrencyCode
        {
            get { return _CurrencyCode; }
            set
            {
                _CurrencyCode = value;
                ValidateProperty(value);
                OnPropertyChanged("CurrencyCode");
            }
        }

        public PriceLevel PriceLevel
        {
            get { return _PriceLevel; }
            set
            {
                _PriceLevel = value;
                ValidateProperty(value);
                OnPropertyChanged("PriceLevel");
            }
        }

        public string Code
        {
            get { return _Code; }
            set
            {
                _Code = value;
                ValidateProperty(value);
                OnPropertyChanged("Code");
            }
        }

        public Customer Customer
        {
            get { return _Customer; }
            set
            {
                _Customer = value;
                ValidateProperty(value);
                OnPropertyChanged("Customer");
            }
        }

        public Employee Sale
        {
            get { return _Sale; }
            set
            {
                _Sale = value;
                ValidateProperty(value);
                OnPropertyChanged("Sale");
            }
        }

        [MaxLength(10)]
        public string OrderNo
        {
            get { return _OrderNo; }
            set
            {
                _OrderNo = value;
                ValidateProperty(value);
                OnPropertyChanged("OrderNo");
            }
        }

        public PaymentTerm PaymentTerm
        {
            get { return _PaymentTerm; }
            set
            {
                _PaymentTerm = value;
            }
        }

        public Location ShippingTo
        {
            get { return _ShippingTo; }
            set
            {
                _ShippingTo = value;
            }
        }

        public Location BillTo
        {
            get { return _BillTo; }
            set
            {
                _BillTo = value;
            }
        }

        public string ShippingTerm
        {
            get { return _ShippingTerm; }
            set { _ShippingTerm = value; }
        }

        public string PaymentMethod
        {
            get { return _PaymentMethod; }
            set { _PaymentMethod = value; }
        }


        [AfterStartDate(StartDatePropertyName = "Date", EndDate = "2020/01/01")]
        public DateTime ShippingDate
        {
            get { return _ShippingDate; }
            set
            {
                _ShippingDate = value;
                ValidateProperty(value);
                this.OnPropertyChanged("ShippingDate");
            }
        }

        public ObservableCollection<OrderDetail> ListOrderDetail
        {
            get { return _ListOrderDetail; }
            set
            {
                _ListOrderDetail = value;
            }
        }

        public override void OnPropertyChanged(string name)
        {
            base.OnPropertyChanged(name);
            base.OnPropertyChanged("IsValid");
        }
    }
}
