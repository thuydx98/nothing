﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTraining.Model.Models
{
    public class OrderDetail : BaseViewModel
    {
        private int _Seq;
        private string _ItemCode;
        private string _Description;
        private string _UOM;
        private double _UnitPrice;
        private int _Quantity;
        private double _Disc;
        private int _Tax;

        public int Seq
        {
            get { return _Seq; }
            set
            {
                _Seq = value;
            }
        }

        public string ItemCode
        {
            get { return _ItemCode; }
            set
            {
                _ItemCode = value;
            }
        }

        public string Description
        {
            get { return _Description; }
            set
            {
                _Description = value;
            }
        }

        public string UOM
        {
            get { return _UOM; }
            set
            {
                _UOM = value;
            }
        }

        public double UnitPrice
        {
            get { return Math.Round(_UnitPrice, 2); }
            set
            {
                _UnitPrice = value;
            }
        }

        public int Quantity
        {
            get { return _Quantity; }
            set
            {
                _Quantity = value;
                OnPropertyChanged("Quantity");
                OnPropertyChanged("Amount");
                OnPropertyChanged("FinalAmt");
                OnPropertyChanged("TaxAmount");
            }
        }

        public double Amount
        {
            get { return Math.Round(UnitPrice * Quantity, 2); }
        }

        public double Disc
        {
            get { return Math.Round(_Disc, 2); }
            set
            {
                _Disc = value;
                OnPropertyChanged("Disc");
                OnPropertyChanged("DiscAmt");
                OnPropertyChanged("FinalAmt");
                OnPropertyChanged("TaxAmount");
            }
        }

        public double DiscAmt
        {
            get { return Math.Round(Amount / 100 * Disc, 2); }
        }

        public double FinalAmt
        {
            get { return Math.Round(Amount - DiscAmt, 2); }
        }

        public int Tax
        {
            get { return _Tax; }
            set
            {
                _Tax = value;
            }
        }

        public double TaxAmount
        {
            get { return Math.Round(FinalAmt / (Tax * 10) / 2, 2); }
        }
    }
}
