﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTraining.Model.Models
{
    public class PaymentTerm
    {
        private string _TermName;

        public string TermName
        {
            get { return _TermName; }
            set
            {
                _TermName = value;
            }
        }
    }
}
