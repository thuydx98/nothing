﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfTraining.Model.Models
{
    public abstract class Person
    {
        private string _id;
        private string _name;

        public string Id
        {
            get { return _id; }
            set { this._id = value; }
        }

        public string Name
        {
            get { return _name; }
            set { this._name = value; }
        }
    }
}
