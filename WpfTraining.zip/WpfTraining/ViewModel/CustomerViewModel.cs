﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Model;
using WpfTraining.Model.Models;

namespace WpfTraining.ViewModel
{
    public class CustomerViewModel
    {
        private List<Person> _Customers;

        public CustomerViewModel()
        {
            _Customers = Database.Instance.customers;
        }

        public List<Person> Customers
        {
            get { return _Customers; }
            set { _Customers = value; }
        }
    }
}
