﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Model;
using WpfTraining.Model.Models;

namespace WpfTraining.ViewModel
{
    public class EmployeeViewModel
    {
        private List<Person> _Employees;

        public EmployeeViewModel()
        {
            _Employees = Database.Instance.employees;
        }

        public List<Person> Employees
        {
            get { return _Employees; }
            set { _Employees = value; }
        }
    }
}
