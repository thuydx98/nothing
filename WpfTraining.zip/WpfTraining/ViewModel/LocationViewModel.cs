﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Model;
using WpfTraining.Model.Models;

namespace WpfTraining.ViewModel
{
    public class LocationViewModel
    {
        private List<Location> _Locations;

        public List<Location> Locations
        {
            get { return _Locations; }
        }

        public LocationViewModel()
        {
            _Locations = Database.Instance.locations;
        }
    }
}
