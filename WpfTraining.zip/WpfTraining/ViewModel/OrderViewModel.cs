﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfTraining.Model;
using WpfTraining.Model.Models;

namespace WpfTraining.ViewModel
{
    public class OrderViewModel: BaseViewModel
    {
        public ICommand DeleteCommand { get; set; }
        public ICommand SelectCommand { get; set; }
        public ICommand DuplicateCommand { get; set; }

        private Order _Order;
        private OrderDetail _SelectedOrderDetail;

        public Order Order
        {
            get { return _Order; }
            set
            {
                _Order = value;
            }
        }
        public OrderDetail SelectedOrderDetail
        {
            get { return _SelectedOrderDetail; }
            set
            {
                _SelectedOrderDetail = value;
            }
        }

        public OrderViewModel()
        {
            _Order = Database.Instance.order;

            DeleteCommand = new RelayCommand<object>(
                (p) =>
                {
                    if (SelectedOrderDetail == null)
                        return false;
                    return true;
                },
                p =>
                {
                    Order.ListOrderDetail.Remove(SelectedOrderDetail);
                }
                );

            SelectCommand = new RelayCommand<object>(
                (p) =>
                {
                    if (SelectedOrderDetail == null)
                        return false;
                    return true;
                },
                p =>
                {
                    MessageBox.Show("Item Code: " + SelectedOrderDetail.ItemCode
                               + "\nDescription: " + SelectedOrderDetail.Description);
                }
                );

            DuplicateCommand = new RelayCommand<object>(
                (p) =>
                {
                    if (SelectedOrderDetail == null)
                        return false;
                    return true;
                },
                p =>
                {
                    Order.ListOrderDetail.Add(SelectedOrderDetail);
                }
                );
        }
    }
}
