﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfTraining.Model;
using WpfTraining.Model.Models;

namespace WpfTraining.ViewModel
{
    public class PaymentTermViewModel
    {
        private List<PaymentTerm> _PaymentTerms;

        public List<PaymentTerm> PaymentTerms
        {
            get { return _PaymentTerms; }
            set
            {
                _PaymentTerms = value;
            }
        }

        public PaymentTermViewModel()
        {
            _PaymentTerms = Database.Instance.paymentTerms;
        }
    }
}
